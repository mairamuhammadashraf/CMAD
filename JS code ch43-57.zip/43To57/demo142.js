
//Chap 43
//Placing scripts

function sum(a,b){
    return a + b;
}

var total = sum(4,5);
alert(total);